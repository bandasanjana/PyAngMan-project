
from functionality import LeaderBoard
from validations import Validate
    
from validations.Validate import Validate_Password,Validate_Command,Validate_Admin_Password
from database.Persistent import display_by_pattern,delete_question_details 
from classes.QuestionClass import Question
from functionality.FetchingRequirements import show_question
from database.Persistent import display_by_category
#trainee 4 import
from database.Persistent import display_question_details, show_recently_added_question,show_recently_edited_question, add_new_question,edit_old_question 
from classes.QuestionClass import Question
from functionality.FetchingRequirements import show_question
from database.Persistent import display_by_category





#1.personalized search
#positive name
LeaderBoard.person_details("sam")
#negative testcase
LeaderBoard.person_details("ramdeen")

#2.leaderboard in general
print(Validate.check_city('ramdeen', "london"))

print(Validate.check_city('sam', "lonndon"))

print(Validate.validate3_10("6"))

print(Validate.validate3_10(""))

print(Validate.validate_guess("0"))
print(Validate.validate_guess("sa"))
print(Validate.validate_guess("a"))
print(Validate.validate_guess("#"))


try:
    print(Validate.validate1_3("2"))
except Exception as e:
    print(e)
try:   
    print(Validate.validate1_3("10"))
except Exception as e:
    print(e)    
try:    
    print(Validate.validate1_3("a"))
except Exception as e:
    print(e) 
try:   
    print(Validate.validate3_10("11"))
except Exception as e:
    print(e)
######################################################################

print(Validate_Password("System"))  #negative testcase for validating password of admin

print(Validate_Password("Admin123@"))   #positive testcase for validating password of admin

print(Validate_Command("password"))

print(Validate_Command("Password"))

print(Validate_Command("paSsWoRD"))

print(Validate_Command("PPpassword"))

print(Validate_Command("password12"))

print(Validate_Command("password PASS"))

print(Validate_Command("pass"))

print(Validate_Command("EDIT"))

print(Validate_Command("eDIt"))

print(Validate_Command(" edit"))

print(Validate_Command("eedit"))

print(Validate_Command("edit12"))

print(Validate_Command("edit 123"))

print(Validate_Command("edit asd"))

print(Validate_Command("edit s12"))

print(Validate_Command("aDD"))

print(Validate_Command(" ADD"))

print(Validate_Command("add 1"))

print(Validate_Command("aDD"))

print(Validate_Command("a DD"))

print(Validate_Command("delete"))#POSITIVE

print(Validate_Command("DeLeTE"))

print(Validate_Command("delete 12"))

print(Validate_Command("delete "))

print(Validate_Command("del"))#NEGATIVE

print(Validate_Command("delete ASD"))

print(Validate_Command("delete @12"))

print(Validate_Command("EDIT"))#POSITIVE

print(Validate_Command("EdIt"))

print(Validate_Command("edit 123"))

print(Validate_Command("edit1s3"))#negative

print(Validate_Command("edit a1@"))

print(Validate_Command("logout"))#positive

print(Validate_Command("lOgOUt"))

print(Validate_Command("logout"))#NEGATIVE

print(Validate_Command("EXIT"))

'''Negative test case for Setting admin password'''

try:
  
    print(Validate_Admin_Password("admin"))
    
except Exception as e:
    print(e)
    
try:
  
    print(Validate_Admin_Password("adminnnnn"))
    
except Exception as e:
    print(e)
    

try:
  
    print(Validate_Admin_Password("admin123"))
    
except Exception as e:
    print(e)

try:
  
    print(Validate_Admin_Password("Admin123"))
    
except Exception as e:
    print(e)
    
    
try:
  
    print(Validate_Admin_Password("Admin Admin123@"))
    
except Exception as e:
    print(e)

'''Positive test case for Setting admin password'''
try:
  
    print(Validate_Admin_Password("Admin123@"))
    
except Exception as e:
    print(e)




#trainee 3 -4 validations
def test_display_by_category_1():
    result=display_by_category("Country")
    assert isinstance(result[0],Question)
    
def test_display_by_category_2():
    result=display_by_category("Actor")
    assert result==None
    
def test_display_by_pattern_1():
    result=display_by_pattern(["","CO",""])
    assert isinstance(result[0],Question)
    
def test_display_by_pattern_2():
    result=display_by_pattern(["X","",""])
    assert result==[]
    
def test_delete_question_details_1():
    result=delete_question_details(2009)
    assert isinstance(result, Question)
    
def test_delete_question_details_2():
    result=delete_question_details(1013)
    assert result==None
    
def test_display_question_details_1():
    result=display_question_details(2006)
    assert isinstance(result, Question)
    
def test_display_question_details_2():
    result=display_question_details(1013)
    assert result==None
   
def test_show_question_1():
    result=show_question(1008)
    assert isinstance(result, list)
    
def test_show_question_2():
    result=show_question(3008)
    assert result==False

#################################################3

    
def test_show_recently_added_queston_1():#If recently added question is there
    result=show_recently_added_question()
    question=result.pop()
    assert isinstance(question, Question)


    
def test_show_recently_edited_queston_1():#If recently edited question is there
    result=show_recently_edited_question()
    question=result.pop()
    assert isinstance(question, Question)

def test_add_new_question_1():
    result=add_new_question("Country", "Qatar", "Easy")
    assert result==True

def test_add_new_question_2():
    result=add_new_question("City", "Jakarta", "Easy")
    assert result==None

def test_add_new_question_3():
    result=add_new_question("Movies", "Singham", "Easy")
    assert result==True

def test_add_new_question_4():
    result=add_new_question("Abc", "Golmaal", "Medium")
    assert result==None
        
def test_edit_old_question_1():
    result=edit_old_question(1001, "Country", "India", "Easy")
    assert result==True

def test_edit_old_question_2():
    result=edit_old_question(1300, "State", "Pakistan", "Easy")
    assert result==None
    
def test_edit_old_question_3():
    result=edit_old_question(2005, "Movies", "Inception", "Easy")
    assert result==True

def test_edit_old_question_4():
    result=edit_old_question(2500, "Actor", "Dhamaal", "Easy")
    assert result==None
  

   
def test_display_question_details_3():
    result=display_question_details(1008)
    assert result==None
    
    
    
def test_display_question_details_4():
    result=display_question_details(2020)
    assert isinstance(result, Question)
   

    




