
from classes.QuestionClass import Question
from classes.DataStructures import Stack
from utility.DBConnectivity import create_connection,create_cursor
from cx_Oracle import DatabaseError
from exceptions.CustomExceptions import InvalidQuestionId,InvalidCategory


def display_by_pattern(pattern):
    question_list=[]
    try:
        con=create_connection()
        cur=create_cursor(con)
        query1="select QuestionId,QuestionName,CategoryName,QuestionLevel from Question "
        if len(pattern[0])!=0:
            query1+="where upper(QuestionName) like '%"+pattern[0]+"%'"
            
        elif len(pattern[1])!=0:
            query1+="where upper(CategoryName) like '"+pattern[1]+"'"
        elif len(pattern[2])!=0:
            query1+="where upper(QuestionLevel) like '"+pattern[2]+"'"
        cur.execute(query1)
        result=cur.fetchall()
        for item in result:
            q1=Question()
            q1.set_question_id(item[0])
            q1.set_question_name(item[1].strip())
            q1.set_category_name(item[2].strip())
            q1.set_question_level(item[3].strip())
            question_list.append(q1)
        return question_list
    except DatabaseError as e:
        print(e)
    except:
        print("Record does not Exist.")
    finally:
        cur.close()
        con.close()

def display_question_details(questionid):
    
    try:
        con=create_connection()
        cur=create_cursor(con)
        cur.execute("select QuestionName,CategoryName,QuestionLevel from Question where QuestionId=:q",{"q":questionid})
        result=cur.fetchall()
        if len(result)==0:
            raise InvalidQuestionId(questionid)
        else:
            ques=Question()
            ques.set_question_name(result[0][0].strip())
            ques.set_category_name(result[0][1].strip())
            ques.set_question_level(result[0][2].strip())
            return ques
    
    except InvalidQuestionId as e:
        print(e)
    except DatabaseError as e:
        print("Record does not Exist.")
    
    finally:
        cur.close()
        con.close()
        
def delete_question_details(questionid):
    try:
        con=create_connection()
        cur=create_cursor(con)
        cur1=create_cursor(con)
        cur2=create_cursor(con)
        cur2.execute("select QuestionName from Question where QuestionId="+str(questionid))
        question=cur2.fetchall()
        if len(question)==0:
            raise InvalidQuestionId(questionid)
        else:
            cur1.execute("select CategoryName,QuestionName,QuestionLevel,QuestionHint from Question where QuestionId="+str(questionid))
            result=cur1.fetchall()
            ques=Question()
            ques.set_category_name(result[0][0].strip())
            ques.set_question_name(result[0][1].strip())
            ques.set_question_level(result[0][2].strip())
            ques.set_question_hint(result[0][3].strip())
            cur.execute("delete from Question where QuestionId="+str(questionid))
            return ques
        
    except InvalidQuestionId as e:
        print(e)
    except DatabaseError as e:
        print(e)
    
    finally:
        cur.close()
        cur1.close()
        cur2.close()
        con.commit()
        con.close()
        
        
def show_recently_added_question():
    question_stack=Stack(5)
    try:
        con=create_connection()
        cur=create_cursor(con)
        cur.execute("select QuestionId,QuestionName,QuestionLevel from (select q1.* from Question q1 where q1.TimeAdded is not Null order by q1.TimeAdded desc) a where rownum>=1 and rownum<=5")
        result=cur.fetchall()
        if len(result)==0:
            return False
        else:
            for item in result:
                q1=Question()
                q1.set_question_id(item[0])
                q1.set_question_name(item[1].strip())
                q1.set_question_level(item[2].strip())
                question_stack.push(q1)
        return question_stack
    
    except DatabaseError as e:
        print(e)
    except:
        print("Record does not Exist.")
    
    finally:
        cur.close()
        con.close()    
        
        
def add_new_question(category,name,level,hint):
    try:
        con=create_connection()
        cur1=create_cursor(con)
        cur2=create_cursor(con)
        cur1.execute("select max(QuestionId) from Question where CategoryName=:c",{"c":category})
        result=cur1.fetchall()

        new_id=result[0][0]+1   

        cur2.execute("insert into Question (QuestionId, CategoryName, QuestionName, QuestionLevel,QuestionHint, TimeAdded) values ('"+str(new_id)+"','"+category+"','"+name+"','"+level+"','"+hint+"',systimestamp)")
        return True
    except DatabaseError :
        print("You have entered Invalid details, try again later...")
    except:
        print("Inappropriate Data.")
        
    finally:
        cur1.close()
        cur2.close()
        con.commit()
        con.close()

def edit_old_question(questionid,category,name,level):
    try:
        con=create_connection()
        cur1=create_cursor(con)
        cur2=create_cursor(con)
        cur2.execute("select QuestionName from Question where QuestionId="+str(questionid))
        question=cur2.fetchall()
        if len(question)==0:
            raise InvalidQuestionId(questionid)
            
        else:
            query="Update Question set TimeEdited=SYSTIMESTAMP,"
            if name!="":
                query+="QuestionName='"+name+"',"
            if category!="":
                query+="CategoryName='"+category+"',"
            if level!="":
                query+="QuestionLevel='"+level+"',"
            query=query.rstrip(",")
            query+=" where QuestionId="+str(questionid)
            cur1.execute(query)
            return True
    
    except InvalidQuestionId as e:
        print(e)
    except DatabaseError as e:
        print("You have entered Invalid details, try again later...")
    
    finally:
        cur1.close()
        cur2.close()
        con.commit()
        con.close()      

def show_recently_edited_question():
    question_stack=Stack(5)
    try:
        con=create_connection()
        cur=create_cursor(con)
        cur.execute("select QuestionId,QuestionName,QuestionLevel from (select q1.* from Question q1 where q1.TimeEdited is not Null order by q1.TimeEdited desc) a where rownum>=1 and rownum<=5")
        result=cur.fetchall()
        if len(result)==0:
            return False
        else:
            for item in result:
                q1=Question()
                q1.set_question_id(item[0])
                q1.set_question_name(item[1].strip())
                q1.set_question_level(item[2].strip())
                question_stack.push(q1)
        return question_stack
    
    except DatabaseError as e:
        print(e)
    except:
        print("Record not Exist")
    
    finally:
        cur.close()
        con.close()    

def display_by_category(category):
    question_list=[]
    category=category.lower()
    try:
        con=create_connection()
        cur=create_cursor(con)
        cur.execute("select QuestionId,QuestionName,CategoryName,QuestionLevel from Question where lower(CategoryName)=:c",{"c":category})
        result=cur.fetchall()
        if len(result)==0:
            raise InvalidCategory(category)
        for item in result:
            q1=Question()
            q1.set_question_id(item[0])
            q1.set_question_name(item[1].strip())
            q1.set_category_name(item[2].strip())
            q1.set_question_level(item[3].strip())
            question_list.append(q1)
        return question_list
    
    except DatabaseError as e:
        print(e)
    except InvalidCategory as e:
        print(e)
    
    finally:
        cur.close()
        con.close()
        
def display_all():
    question_list=[]
    try:
        con=create_connection()
        cur=create_cursor(con)
        cur.execute("select QuestionId,QuestionName,CategoryName,QuestionLevel from Question")
        result=cur.fetchall()
        for item in result:
            q1=Question()
            q1.set_question_id(item[0])
            q1.set_question_name(item[1].strip())
            q1.set_category_name(item[2].strip())
            q1.set_question_level(item[3].strip())
            question_list.append(q1)
        return question_list
    
    except DatabaseError as e:
        print(e)
    except:
        print("Record not Exist")
    
    finally:
        cur.close()
        con.close()