
from utility import DBConnectivity
from classes import QuestionClass
import  random

from cx_Oracle import DatabaseError
# This module fetches questions from database
def fetch_questions(category_type):
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        cur1=DBConnectivity.create_cursor(con)
        cur2=DBConnectivity.create_cursor(con)
        list_of_questions=[]
#         list_of_questions_medium=[]
#         list_of_questions_hard=[]

        cur.execute("select QuestionId, QuestionName,questionhint from Question where lower(CategoryName)=:category and lower(QuestionLevel)='easy'",{"category":category_type.lower()})

        temp_list=cur.fetchall()
      
        check=[]
        count=0
        while(count<3):# 3 different easy questions are selected and saved in list
            k=random.randrange(0,len(temp_list))
            if(k not in check):
                count+=1
                check.append(k)
                list_of_questions.append(temp_list[k])
                    
                
         
        #######################Group71
        
       
        cur1.execute("select QuestionId, QuestionName,questionhint  from Question where lower(CategoryName)=:category and lower(QuestionLevel)='medium'",{"category":category_type.lower()})
        temp_list=cur1.fetchall()
        
        check=[]
        count=0
        while(count<2):# 2 different easy questions are selected and saved in list
            k=random.randrange(0,len(temp_list))
            if(k not in check):
                count+=1
                check.append(k)
                list_of_questions.append(temp_list[k])
                    
            
        ##########################    
      
        cur2.execute("select QuestionId, QuestionName ,questionhint from Question where lower(CategoryName)=:category and lower(QuestionLevel)='hard'",{"category":category_type.lower()})
        temp_list=cur2.fetchall()
        check=[]
        count=0
        while(count<2):# 2 different easy questions are selected and saved in list
            k=random.randrange(0,len(temp_list))
            if(k not in check):
                count+=1
                check.append(k)
                list_of_questions.append(temp_list[k])
            
        list_of_final_questions=[]
        for quest in range(0,len(list_of_questions)):
            
            '''
            In this loop, we are creating a product object for every row
            and setting the values from the row into the product object
            '''
            question=QuestionClass.Question()
            question.set_question_id(list_of_questions[quest][0])
            question.set_question_name(list_of_questions[quest][1].strip())
            question.set_question_hint(list_of_questions[quest][2].strip())
            
            '''
            Here were are adding the product to a list
            
            '''
            list_of_final_questions.append(question)
             
        return list_of_final_questions
    except DatabaseError as e:
        if (e.split(":")[0]=="ORA-00942"):
            print("Database Not Available")
        else:
            print("Some Database Error")
        
         
    finally:
        cur.close()
        con.close()
