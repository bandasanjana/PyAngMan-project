
from utility import DBConnectivity
from classes import PlayerClass
from cx_Oracle import DatabaseError
def check(name,city):
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
       
        #To get to know whether there is such player or not. Fetches row from here.
        cur.execute("select * from player where lower(PlayerName)=:nm",{"nm":name.lower()})

        temp_list=cur.fetchall()
        if(len(temp_list)==0):
            return "0" #no such player
        if(temp_list[0][1].lower()!=city.lower()):
            return "1"
        list_of_occurnce=[]
        for row in range(0,len(temp_list)):
            Player_obj=PlayerClass.Player()   #Player object with such details are set
            Player_obj.set_player_name(temp_list[row][0])
            Player_obj.set_city(temp_list[row][1])
            Player_obj.set_category_name(temp_list[row][2])
            Player_obj.set_points(temp_list[row][3])
            list_of_occurnce.append(Player_obj)
            
        return (list_of_occurnce)
        #Entering the player in database after user accepts to play and is a new player

    except DatabaseError as e:
        if(e.split(":")[0]=="ORA-00942"):
            print("Database Not Available")
        else:
            print("Some Database Error")
        
    finally:

        cur.close()
        con.close()
