
from utility import DBConnectivity
import sys
from cx_Oracle import DatabaseError


def Fetch_Easy_Questions():
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        cur1=DBConnectivity.create_cursor(con)

        list_easy=[]
        
        
#         "select (SuccessfulAttempts/NoOfAttempts) as 'Attempts' from Question"
        cur.execute("select QuestionId from Question where (SuccessfulAttempts/NoOfAttempts)>0.8 and NoOfAttempts!=0 and lower(QuestionLevel)!='easy'")
        list_easy=cur.fetchall()
        cur1.execute("select QuestionId from Question where NoOfAttempts=0 and lower(QuestionLevel)='easy'")
        for row in cur1:
            list_easy.append(row)

#         print(list_easy)
        return list_easy

        
    except DatabaseError as e:
        if (e.split(":")[0]=="ORA-12899"):
            print("Field name must be maximum 20 characters long")
        elif (e.split(":")[0]=="ORA-00942"):
            print("Database Not Available")
        else:
            print("Some Database Error")
        
        
    finally:
        cur.close()
        con.close()

def Fetch_Medium_Questions():
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        cur1=DBConnectivity.create_cursor(con)
        list_medium=[]
        
        cur.execute("select QuestionId from Question where ((SuccessfulAttempts/NoOfAttempts)>0.5 and (SuccessfulAttempts/NoOfAttempts)<=0.8) and NoOfAttempts!=0 and lower(QuestionLevel)!='medium'")
        list_medium=cur.fetchall()
        cur1.execute("select QuestionId from Question where NoOfAttempts=0 and lower(QuestionLevel)='medium'")
        for row in cur1:
            list_medium.append(row)

#         print(list_medium)
        return list_medium
    except DatabaseError as e:
        if (e.split(":")[0]=="ORA-12899"):
            print("Field name must be maximum 20 characters long")
        elif (e.split(":")[0]=="ORA-00942"):
            print("Database Not Available")
        else:
            print("Some Database Error")
        
    finally:
        cur.close()
        con.close()

def Fetch_Hard_Questions():
    
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        cur1=DBConnectivity.create_cursor(con)
        list_hard=[]
        
        cur.execute("select QuestionId from Question where (SuccessfulAttempts/NoOfAttempts)<=0.5 and NoOfAttempts!=0 and lower(QuestionLevel)!='hard'")
        list_hard=cur.fetchall()
        cur1.execute("select QuestionId from Question where NoOfAttempts=0 and lower(QuestionLevel)='hard'")
        for row in cur1:
            list_hard.append(row)

        return list_hard
    except DatabaseError as e:
        if (e.split(":")[0]=="ORA-12899"):
            print("Fieldname must be maximum 20 characters long")
        elif (e.split(":")[0]=="ORA-00942"):
            print("Database Not Available")
        else:
            print("Some Database Error")
        
    finally:
        cur.close()
        con.close()    
        
# fetch_Easy_Questions()
# Fetch_Medium_Questions()
# Fetch_Hard_Questions()
def Fetch_Old_Password():
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        old_pwd=""
        
        cur.execute("select Password from Admin")
        old_pwd=cur.fetchall()
#         print(old_pwd)
        return old_pwd[0][0]
    except Exception:
        print("Database connection failureeee")
        sys.exit()
        return
        
        
    finally:
        cur.close()
        con.close() 
def Update_Password(new_pwd):
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        
#         cur.execute("update Admin set password= '"+new_pwd+"'")#:pwd",{"pwd":new_pwd})
        cur.execute("update Admin set password=:pwd",{"pwd":new_pwd})

        con.commit()
#         cur.execute("select * from admin")
        
    except Exception:
        print("Database connection failure")
        sys.exit()
    finally:
        cur.close()
        con.close()
    
    