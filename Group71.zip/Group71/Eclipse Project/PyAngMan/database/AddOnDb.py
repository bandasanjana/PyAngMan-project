
from utility import DBConnectivity
from exceptions import CustomExceptions
from classes import PlayerClass
def data_add_on(person):
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        cur1=DBConnectivity.create_cursor(con)
        ''' finding the entire relevant data that belongs to that person'''
        cur.execute("select *  from player where lower(PlayerName)=:nm",{"nm":person.lower()})

        temp_list=cur.fetchall()
        if(len(temp_list)==0):
            raise CustomExceptions.InvalidPerson# if no such person exist the exception is raised
        else:
            cur1.execute(" select rank from (select playername,rownum rank from (select playername from player group by playername order by sum(points) desc)) where lower(PlayerName)=:nm",{"nm":person.lower()})
            temp=cur1.fetchall()
            rank=temp[0][0]
            list_of_occurnce=[]
            for x in range(0,len(temp_list)):   
                Player_obj=PlayerClass.Player()#player object with such details are set
                Player_obj.set_player_name(temp_list[x][0])
                Player_obj.set_city(temp_list[x][1])
                Player_obj.set_category_name(temp_list[x][2])
                Player_obj.set_points(temp_list[x][3])
                list_of_occurnce.append(Player_obj)
            list_of_occurnce.append(rank)#last element of the list will be rank
            return (list_of_occurnce)
            
    except CustomExceptions.InvalidPerson as e:
        print(e)
        return "no" 
    except Exception:
        print("There is no data to show.\tDatabase missing")
    finally:
        cur.close()
        con.close()