

from utility import DBConnectivity
from cx_Oracle import DatabaseError
def category_check(name,city,category):
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        cur1=DBConnectivity.create_cursor(con)
        
        category1=category.title()
        
        cur.execute("select playername  from  player where lower(playername)=:name and lower(categoryname)=:category",{"name":name.lower(),"category":category.lower()})
        temp=cur.fetchall()
        if(len(temp)==0):
            cur1.execute("insert into player values(:a,:b,:c,:d)",{"a":name,"b":city,"c":category1,"d":0})
            
        con.commit()
        
        '''Entering the player in database after user accepts to play and is a new player'''
        
    except DatabaseError as e:
        if (e.split(":")[0]=="ORA-12899"):
            print("Field name must be maximum 20 characters long")
        elif (e.split(":")[0]=="ORA-00942"):
            print("Database Not Available")
        else:
            print("Some Database Error")
    finally:

        cur.close()
        con.close()
