
from utility import DBConnectivity
from exceptions import CustomExceptions
def checkviadb(name,city):
    city1=city.lower()
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
    
        cur.execute("select PlayerName,city  from player where lower(PlayerName)=:nm",{"nm":name.lower()})
        temp_list=cur.fetchall()
        if(len(temp_list)==0):              #when there is no such player in database
            return "New"
        else:
            
            if(city1!=temp_list[0][1].lower()):
                raise CustomExceptions.InvalidCity
            else:
                return "existing"       #yes, the player is existing in the database
            
    except CustomExceptions.InvalidCity as e:
        print(e)
        return "Invalid City"  #player entered wrong city
    finally:
        cur.close()
        con.close()