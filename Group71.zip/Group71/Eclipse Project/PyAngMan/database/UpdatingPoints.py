
from utility import DBConnectivity
from cx_Oracle import DatabaseError
def update_score(name,city,categoryy,points,data):
    data=data.lower()
    if(data=="n"):
        try:
            con=DBConnectivity.create_connection()
            cur=DBConnectivity.create_cursor(con)
            #DATA=N means its new player and enter into db
            categoryy=categoryy.title()
            cur.execute("insert into player values(:a,:b,:c,:d)",{"a":name,"b":city,"c":categoryy,"d":points})
          
            con.commit()
            return ("Its Ok!! It was your first attempt")
        #entering the player in db after user accepts to play and is new player
  
        except DatabaseError as e:
            if (e.split(":")[0]=="ORA-12899"):
                print("Field name must be maximum 20 characters long")
            else:
                print("Some Database Error")
        
        finally:

            cur.close()
            con.close()

    else:
        try:
            con=DBConnectivity.create_connection()
            cur=DBConnectivity.create_cursor(con)
            #if its old or existing player(E) then we fetch its points from db
            categoryy=categoryy.lower()
            cur.execute("select points from player where lower(playername) =:pnm and lower(categoryname)=:categ",{"pnm":name.lower(),"categ":categoryy})
            score=cur.fetchall()
            if(len(score)!=0):
                score=score[0][0]
                if (score>=points):#best of points are send to db
                    return "Oops!! Not your best ..  best score was "+str(score)
                else:
                    categoryy=categoryy.lower()
                    cur.execute("update player set points=:pts where lower(playername) =:pnm and lower(categoryname)=:categ",{"pnm":name.lower(),"categ":categoryy,"pts":points})
                    con.commit()
                return "Congrats at your best.. new high score"
            else:
                categoryy=categoryy.title()
                cur.execute("insert into player values(:a,:b,:c,:d)",{"a":name,"b":city,"c":categoryy,"d":points})
                con.commit()
                return "It was your first attempt in this category"
         
         
            
           
        #entering the player in db after user accepts to play and is new player
        except DatabaseError as e:
            if (e.split(":")[0]=="ORA-12899"):
                print("Field name must be maximum 20 characters long")
            else:
                print("Some Database Error")
                
        finally:

            cur.close()
            con.close()
            
    