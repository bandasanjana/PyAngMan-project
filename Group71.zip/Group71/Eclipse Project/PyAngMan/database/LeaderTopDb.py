
from utility import DBConnectivity
from classes import PlayerClass
from exceptions import CustomExceptions
from cx_Oracle import DatabaseError
def top(city):                      # Finding top player via city. First requirement of Leader board
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        city=city.lower()
        cur.execute("select *  from (select PlayerName , sum(Points)  from player where lower(City) =:Cit  group by PlayerName order by sum(Points) desc  ) where rownum<=5",{"Cit":city})
        temp_list=cur.fetchall()
        final_top=[]                # This query finds players with the selected city
       
        for player_name,summ  in temp_list:
            player_obj=PlayerClass.Player()                     #values set in player object
            player_obj.set_player_name(player_name)
            player_obj.set_points(summ)
            final_top.append(player_obj)
            
        return final_top
    except DatabaseError as e:
        if (e.split(":")[0]=="ORA-12899"):
            print("Field name must be maximum 20 characters long")
        elif (e.split(":")[0]=="ORA-00942"):
            print("Database Not Available")
        else:
            print("Some Database Error")
    finally:
        cur.close()
        con.close()

def top_category(categ,playerr,to_show,enter_cityy):
    #Finding the top player via category
    try:
        con=DBConnectivity.create_connection()
        cur=DBConnectivity.create_cursor(con)
        
        PlayerName=-1
        CategoryName=-1
        Points=-1
        city=-1
        #initial values are set to -1 because if they are not found in to_show they will have default value -1
        for x in range(0,len(to_show)):     #if name found it is changed to player_name , if category found it is changed to category_name
            if(to_show[x].lower()=="name"):
                PlayerName=x        #if any of details found in to_show, then its position is noted in respective values
                to_show[x]="PlayerName"
            elif(to_show[x].lower()=="category"):
                CategoryName=x
                to_show[x]="CategoryName"
            elif(to_show[x].lower()=="points"):
                if(categ==""):
                    to_show[x]="sum(Points)"
                Points=x
            elif(to_show[x].lower()=="city"):
                city=x
            else:
                raise CustomExceptions.InvalidInputException
        if("CategoryName" not in to_show and categ==""):
            #if category not selected
            lis=[]
            lis.append("CategoryName")
            CategoryName=len(to_show)
            to_show.extend(lis)
  
                
                
            
                
         
        string_fetched=",".join(to_show)

        
        #Final string is achieved and send to database
        categ1=categ.lower()
        if(categ!=""):
            cur.execute("select *  from (select "+string_fetched+"  from player where lower(CategoryName)=:Cit  and lower(city)=:cat  order by points desc ) where rownum<=:playerr ",{"Cit":categ1,"playerr":playerr,"cat":enter_cityy.lower()})       
            
        else:
            if("sum(Points)" in to_show):
                index_found=to_show.index('sum(Points)')
                to_show[index_found]="points"
                string_fetched=",".join(to_show)
                    
            cur.execute("select *  from (select "+string_fetched+"  from player where  lower(city)=:cat  order by points desc) where rownum<=:playerr ",{"playerr":playerr,"cat":enter_cityy.lower()})


        temp_list=cur.fetchall()
      
        final_top=[]
        #player object with different values are set ..
        for one  in range(0,len(temp_list)):
            
            player_obj=PlayerClass.Player()
            if(PlayerName!=-1):
                player_obj.set_player_name(temp_list[one][PlayerName])
            if(city!=-1):
                player_obj.set_city(temp_list[one][city])
            if(Points!=-1):
                player_obj.set_points(temp_list[one][Points])
            if(CategoryName!=-1):
                player_obj.set_category_name(temp_list[one][CategoryName])
                
                
            
            final_top.append(player_obj)
            
        return final_top
    
    except CustomExceptions.InvalidInputException as e:
        print(e)
        return 1
        
    finally:
        cur.close()
        con.close()
        