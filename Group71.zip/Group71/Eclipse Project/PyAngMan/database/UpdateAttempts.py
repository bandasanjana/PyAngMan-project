
from utility import DBConnectivity
from cx_Oracle import DatabaseError
def updating_attempts(attempt_upto,solved_questions):
    try:
        con=DBConnectivity.create_connection()
        # this function update the no of attempts and successful  attempts in question
        for questions in attempt_upto:
            cur=DBConnectivity.create_cursor(con)
           
            cur.execute("update question  set NoOfAttempts =NoOfAttempts +1 where QuestionId  =:pnm ",{"pnm":questions})
            con.commit()
        for questions in solved_questions:
            cur=DBConnectivity.create_cursor(con)
            cur.execute("update question set SuccessfulAttempts =SuccessfulAttempts  +1 where QuestionId  =:pnm ",{"pnm":questions})
            con.commit()
        #entering the player in database after user accepts to play and is new player
    except DatabaseError as e:
        if (e.split(":")[0]=="ORA-00942"):
            print("Database Not Available")
        else:
            print("Some Database Error")
    finally:

        cur.close()
        con.close()
