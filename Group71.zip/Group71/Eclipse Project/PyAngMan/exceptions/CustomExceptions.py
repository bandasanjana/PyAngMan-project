

'''
This file has all the custom exceptions needed for the project
'''
class InvalidInputException(Exception):
    def __init__(self):#if in details field in leader board user tries to fetch invalid column
        super().__init__("Invalid column to fetch")
        
class InvalidCity(Exception):
    def __init__(self):#user entered invalid city in leader board
        super().__init__("Please enter the city you are user of!")

class InvalidPerson(Exception):
    def __init__(self):#in add on feature no such player ever played
        super().__init__("Given person has never played this game")
        
class InvalidInputLeaderboard(Exception):
    def __init__(self):#invalid input in leader board
        super().__init__("Please enter appropriate input")
        
class NotRightInputException(Exception):
    def __init__(self):#invalid input in leaderboard
        super().__init__("Please enter an input between 1-3")
    
class Space_Not_AllowedException(Exception):
    def __init__(self):#invalid input in leaderboard
        super().__init__("Please do not enter space")
        
class Only_Num_SpecialException(Exception):
    def __init__(self):#invalid input in leaderboard
        super().__init__("Please  enter an alphabet as well ")
        
class NumberException(Exception):
    def __init__(self):
        message="Password should include at-least 1 number"
        super().__init__(message)
        
class UpperCaseException(Exception):
    def __init__(self):
        message="Password should include at-least 1 uppercase letter"
        super().__init__(message)
        
class SpecialCharacterException(Exception):
    def __init__(self):
        message="Password should include atleast 1 special character"
        super().__init__(message)
        
class SpaceException(Exception):
    def __init__(self):
        message="Password cannot include space"
        super().__init__(message)

class LengthException(Exception):
    def __init__(self):
        message="Password should have at-least 8 characters"
        super().__init__(message)

class InvalidPasswordException(Exception):
    def __init__(self):
        message="** INVALID PASSWORD"
        super().__init__(message)
        
class InvalidCommand(Exception):
    def __init__(self):
        message="** INVALID COMMAND"
        super().__init__(message)
        
class SamePasswordException(Exception):
    def __init__(self):
        message="New Password cannot be same as the old password"
        super().__init__(message)
class PasswordChangeLimit(Exception):
    def __init__(self):
        message="Password change limit exceeded"
        super().__init__(message)
        
class InvalidEntry(Exception):
    def __init__(self):
        message="Enter valid input"
        super().__init__(message)
    

#TRAINEE4
class InvalidQuestionId(Exception):
    def __init__(self,msg):
        new_msg="The given QuestionId:"+str(msg)+" is not Available, please enter correct QuestionId."
        super().__init__(new_msg)

class InvalidCategory(Exception):
    def __init__(self,msg):
        new_msg="The given Category:"+msg+" is not Available, please enter correct Category."
        super().__init__(new_msg)


