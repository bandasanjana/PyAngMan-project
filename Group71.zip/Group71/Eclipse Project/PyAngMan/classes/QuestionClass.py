class Question:
    def __init__(self):
        self.__question_id=None
        self.__question_name=None
        self.__category_name=None
        self.__question_level=None
        self.__total_attempts=None
        self.__successful_attempts=None
        self.__time_added=None
        self.__question_hint=None
        self.__time_edited=None

    def get_question_id(self):
        return self.__question_id


    def get_question_name(self):
        return self.__question_name


    def get_category_name(self):
        return self.__category_name


    def get_question_level(self):
        return self.__question_level


    def get_total_attempts(self):
        return self.__total_attempts


    def get_successful_attempts(self):
        return self.__successful_attempts


    def get_time_added(self):
        return self.__time_added


    def get_question_hint(self):
        return self.__question_hint


    def get_time_edited(self):
        return self.__time_edited


    def set_question_id(self, value):
        self.__question_id = value


    def set_question_name(self, value):
        self.__question_name = value


    def set_category_name(self, value):
        self.__category_name = value


    def set_question_level(self, value):
        self.__question_level = value


    def set_total_attempts(self, value):
        self.__total_attempts = value


    def set_successful_attempts(self, value):
        self.__successful_attempts = value


    def set_time_added(self, value):
        self.__time_added = value


    def set_question_hint(self, value):
        self.__question_hint = value


    def set_time_edited(self, value):
        self.__time_edited = value


    


        