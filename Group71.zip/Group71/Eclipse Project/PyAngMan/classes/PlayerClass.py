
class Player():
    def __init__(self):
        '''   making instance variable equal to empty string to print the data in the table without the none type error  '''
        self.__player_name="" 
        self.__city=""
        self.__category_name="" 
        self.__points=""
    #getters and setters of the instances
    def get_player_name(self):
        return self.__player_name


    def get_city(self):
        return self.__city


    def get_category_name(self):
        return self.__category_name


    def get_points(self):
        return self.__points


    def set_player_name(self, value):
        self.__player_name = value


    def set_city(self, value):
        self.__city = value


    def set_category_name(self, value):
        self.__category_name = value


    def set_points(self, value):
        self.__points = value

    

    
    
    ''' method to show details of object when called'''
    def player_details(self):
        return (self.get_player_name()+"\t"+str(self.get_points())+"\t"+self.get_category_name()+"\t"+self.get_city())



        
        