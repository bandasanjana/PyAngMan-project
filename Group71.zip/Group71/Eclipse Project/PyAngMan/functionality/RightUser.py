
from validations import Validate
def name_city(name,city):
    return Validate.check_city(name, city)
    
