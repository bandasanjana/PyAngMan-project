
from functionality import MainPlay
from utility import ShowGraphics
from validations import Validate
from exceptions import CustomExceptions
from exceptions.CustomExceptions import InvalidEntry
from database import CheckNewExistdb,UpdatingPoints,UpdateAttempts
import re

def player_type():
    while(True):
        try:
            data=input("New Player or Existing Player (N/E)?")
            valid= Validate.Validate_E_or_N(data)
            if(valid==False):
                raise InvalidEntry
            else:
                break
        except InvalidEntry as e:
            print(e)
        except:
            print("Error")
    return data



def initial_play():
    
    while(True):
        data=player_type()
        while(True):
            name=input("What is your name?")
            try:
                Validate.validate_name(name)
                break
            except CustomExceptions.Space_Not_AllowedException as e:
                print(e)
            except CustomExceptions.Only_Num_SpecialException as e:
                print(e)
            
        city=input("Which is your city?") 
        p=CheckNewExistdb.check(name,city)
        if(p=="1"):
            print("Please enter the city you are user of  and try again! ")
            continue
        if(p=="0" and data.lower()=="e"):##### p=0 not found in db
            print("No such player exists")
            print("enter again")
            continue
        if(p=="0" and data.lower()=="n"):####p=0 not found and new db
            
            break
        if(p!="0" and data.lower()=="n"):####p=0 not found and new db
            print("This player  name already exist choose another name")
            continue
        if(p!="0" and data.lower()=="e"):####p=0 not found and new db
            print("welcome again")
            break
                
                
                
    while(True):            
        print("Choose category: (1-3)")
        print("1.    Country")
        print("2.    Movies")
        print("3.    Exit")
        option=(input())

        if(option=="1"):
            print("Play PyAngMan:")

            des=start_playing(name,city,"Country",data)
            if(des=="y"):
                continue
            else:
                return "n"
            
        elif(option=="2"):
            print("Play PyAngMan:")
            des=start_playing(name,city,"Movies",data)
            if(des=="y"):
                continue
            else:
                return 
        elif(option=="3"):
            return
        else:
            print("not valid input")
    
       
        
            
def start_playing(name,city,categoryy,data):
    
    
    points=0  #for showing points earned for current game
    questions=MainPlay.play_now(categoryy)#getting list of objects having questions from functionality layer
    
    total=0
#     flag=1
    '''This while loop loops the 7 Questions'''
   
    solved_questions=[]
    attempt_upto=[]
    while(total<7):#here total refers to no of questions to succeed and total questions fetched as object in list
        typed_letter=[]
        quest=questions[total]  #creating variable to store one question for every loop
        attempt_upto.append(quest.get_question_id())
        total=total+1
       
        q_name=quest.get_question_name()#contains question name
        dash_co=[]#creating empty list for showing guessed string by player
        

        for x in range (0,len(q_name)):
            if q_name[x]==" ":
                dash_co.append(" ")
            else:
                dash_co.append("_") #first appending dashes in the list
        stage=0  #user can have 6 failed attempts only(0-5),at 6-game over
        dummy=0
        '''This inner loop provides maximum 6 failed attempts'''
        while(stage!=7):# giving six attempts
            
            if(stage==6):
                ShowGraphics.show_hang_man(stage)
                dummy=1 #variable to exit when failed attempts exceeded
                break #exits the inner loop
            ShowGraphics.show_hang_man(stage)#for showing corresponding graphics according to user's status
            
#             print("hint : "+quest.get_questionhint())
            print( "Answer:"+" ".join(dash_co))#for showing the guessed answer
            
            #guess=input("Guess a letter (A-Z):")#taking input from user
            #length=1
            #guess==#,0
            #alphabet
            #alphabet not pressed b4
            while(True):
                guess=input("Guess a letter (A-Z):")
                desire=Validate.validate_guess(guess)
                if(desire==True):
                    if(guess.lower()  in typed_letter ):
                        print("Enter something new")
                        continue
                    else:
                        break
                elif(desire=="cheat code"):
                    print("hint : "+quest.get_question_hint())
                    continue
                elif(desire=="End game"):
                    dummy=1
                    break
                else:
                    print("Invalid input")
                    continue
                    
            if(dummy==1):
                break            
                

            typed_letter.append(guess.lower())
            
        
            guess=guess.lower()                 #making comparison case insensitive
            right=0                             #initializing variable to store whether user guessed right
            for m in re.finditer(guess,q_name.lower()):     #This is used because there may be multiple occurrences of an alphabet
               
                right=1                                      #Right guess
                if m.start()==0:                    #if guessed alphabet is the first letter
                    dash_co.pop(m.start())
                    dash_co.insert(m.start(), guess.upper())
                else:                            #if guessed alphabet is other than the first letter
                    dash_co.pop(m.start())
                    dash_co.insert(m.start(), guess)
                
            if(dash_co.count("_")==0):              #checking whether player has completely guessed the question
                dummy=2                             #for successful attempt of a question
                print("Answer:"+" ".join(dash_co))#showing final answer
                solved_questions.append(quest.get_question_id())
                if(total!=6):
                    print("Congrats, here's the next one:")
                break
            elif(right):
                continue
            else:                               #user has done a wrong guess
                stage+=1                        #graphic image is updated
                
        if(dummy==1):                           #executed when user has exceeded failed attempts' limit or has quit
            break
            
        if(dummy==2):                           #for calculation of points on successful guesses
            if(total<3):                        #points for easy questions
                points=points-stage
                points+=10
            
            elif(total>=3 and total<5):             #points for medium level question
                points=points-stage
                points+=15
            else:                               #pints for hard level questions
                points=points-stage
                points+=20    
            
    print("Thanks For Playing . Your Score is : "+str(points))      #showing total score
    data1=data[0]
    x=UpdatingPoints.update_score(name,city,categoryy,points,data1)
    UpdateAttempts.updating_attempts(attempt_upto,solved_questions)
    print(x)
  
    while(True):
        deszire=input("Wanna Play Again (y/n)")
        if(Validate.Validate_Y_or_N(deszire)):
            if(deszire.lower()=="y"):
                data="e"
                start_playing(name, city, categoryy, data)
            elif(deszire.lower()=="n"):
                return "n"
        else:
            print("invalid input")