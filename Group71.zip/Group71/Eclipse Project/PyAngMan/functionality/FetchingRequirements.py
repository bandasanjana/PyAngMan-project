
from database.Persistent import display_question_details,delete_question_details,show_recently_added_question
from database.Persistent import display_by_pattern,add_new_question,show_recently_edited_question,edit_old_question
from database.Persistent import display_by_category,display_all

''' Fetching details based on the various admin commands'''

def show_question(input_question_id):
    question_list=[]
    question_obj=display_question_details(input_question_id)
    if question_obj==None:
        return False
    else:
        question_list.append(question_obj.get_question_name())
        question_list.append(question_obj.get_category_name())
        question_list.append(question_obj.get_question_level())
        return question_list
        
def undo_deleted_question(question):
    category=question.get_category_name()
    name=question.get_question_name()
    level=question.get_question_level()
    hint=question.get_question_hint()
    result=add_new_question(category,name,level,hint)
    if result==True:
        return True
    else:
        return False

def delete_question(input_question_id):
    result=delete_question_details(input_question_id)
    if result==None:
        return False
    else:
        return result
    
def delete_pattern(pattern):
    pattern_matching_list=[]
    result=display_by_pattern(pattern)
    for item in result:
        temp_list=[]
        temp_list.append(item.get_question_id())
        temp_list.append(item.get_question_name())
        temp_list.append(item.get_category_name())
        temp_list.append(item.get_question_level())
        pattern_matching_list.append(temp_list)
    return pattern_matching_list
    
def show_recent_question():
    result=show_recently_added_question()
    if result==False:
        return False
    else:
        question_list=[]
        while not result.is_empty():
            item=result.pop()
            temp_list=[]
            temp_list.append(item.get_question_id())
            temp_list.append(item.get_question_name())
            temp_list.append(item.get_question_level())
            question_list.append(temp_list)
            question_list.reverse()
        return question_list
        
def add_question(category,name,level,hint):
    result=add_new_question(category,name,level,hint)
    if result==True:
        return True
    else:
        return False
    
def edit_question(questionid,category,name,level):
    result=edit_old_question(questionid,category,name,level)
    if result==None:
        return False
    else:
        return True    

def recently_edited_question():
    result=show_recently_edited_question()
    if result==False:
        return False
    else:
        question_list=[]
        while not result.is_empty():
            item=result.pop()
            temp_list=[]
            temp_list.append(item.get_question_id())
            temp_list.append(item.get_question_name())
            temp_list.append(item.get_question_level())
            question_list.append(temp_list)
            question_list.reverse()
        return question_list
    
def show_by_category(category):
    list_of_category_questions=[]
    questionlist=display_by_category(category)
    if questionlist==None:
        return False
    else:
        for item in questionlist:
            temp_list=[]
            temp_list.append(item.get_question_id())
            temp_list.append(item.get_question_name())
            temp_list.append(item.get_category_name())
            temp_list.append(item.get_question_level())
            list_of_category_questions.append(temp_list)
        return list_of_category_questions

def show_all():
    list_of_all_questions=[]
    questionlist=display_all()
    for item in questionlist:
        temp_list=[]
        temp_list.append(item.get_question_id())
        temp_list.append(item.get_question_name())
        temp_list.append(item.get_category_name())
        temp_list.append(item.get_question_level())
        list_of_all_questions.append(temp_list)
    return list_of_all_questions