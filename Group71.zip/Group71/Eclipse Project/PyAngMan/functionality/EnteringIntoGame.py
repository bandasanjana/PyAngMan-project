
from database import EnterInGameDb
def enter_into_game(name,city,category1):
    return EnterInGameDb.indbgame( name,city,category1)
#Here database is entered with the appropriate value
