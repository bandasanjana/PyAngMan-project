from database import LeaderTopDb

def top_leader(city):
    
    return LeaderTopDb.top(city)

def top_category_function(categ,playerr,to_show,city):
    return LeaderTopDb.top_category(categ,playerr,to_show,city)
