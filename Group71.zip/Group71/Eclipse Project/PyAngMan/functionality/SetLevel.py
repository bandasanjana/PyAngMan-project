
from database import FetchActionItems
def Action_Items_Easy():
    easy_list=FetchActionItems.Fetch_Easy_Questions()#gets the list of questionId from database package
    if(len(easy_list)==0):
        return 0
    return easy_list
    
def Action_Items_Medium():
    medium_list=FetchActionItems.Fetch_Medium_Questions()#gets the list of questionId from database package
    if(len(medium_list)==0):
        return 0
    return medium_list

def Action_Items_Hard():
    hard_list=FetchActionItems.Fetch_Hard_Questions()#gets the list of questionId from database package
    if(len(hard_list)==0):
        return 0
    return hard_list

def Old_Password():#for changing password
    old_pwd=FetchActionItems.Fetch_Old_Password()
    return old_pwd

def Change_Password(new_pwd):
    FetchActionItems.Update_Password(new_pwd)
    

    
    
    
    