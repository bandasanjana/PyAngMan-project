
from validations import Validate
from functionality import SetLevel
from exceptions.CustomExceptions import NumberException,LengthException,SpaceException,SpecialCharacterException,UpperCaseException
from exceptions.CustomExceptions import InvalidCommand,InvalidPasswordException,SamePasswordException,PasswordChangeLimit
from functionality.FetchingRequirements import add_question,show_recent_question,show_all,show_by_category,show_question,delete_pattern,delete_question,undo_deleted_question,edit_question,recently_edited_question


#Trainee2
def Admin_Menu():
        
    outer_loop=1  
    '''This try block will keep on asking for password until user enters the correct password'''
    while(outer_loop==1):
        try:
            
            password=input("Password: ")    #Takes password as input from Admin
            value=Validate.Validate_Password(password) #validates password entered
            if value==False:     #if entered password does not match
                raise InvalidPasswordException
    
            if value==True:     #if entered password matches
                print("Login Successful.")
                '''Fetching list of questions '''
                show_questions_list()
                print("===============================")
                flag=1      #variable initialized to break loop when Admin wants to logout 
                while(flag==1):
                    
                    try:
                        command=input("What would you like to do?")
                        cmd=Validate.Validate_Command(command)       #validating entered command
                        if cmd==False:
                            raise InvalidCommand

                        else:
                            '''Password Module'''
                            
                            if command.lower()=="password":         
                                old_pwd=input("Old Password: ")
                                value=Validate.Validate_Password(old_pwd) 
                                if value==False:
                                    raise InvalidPasswordException
    
                                password_flag=1                     #variable initialized to exit out of loop when password is changed successfully
                                while(password_flag==1):
                                    try:
                                        new_pwd=input("New Password:  ")
                                    
                                        if Validate.Validate_Password(new_pwd)==True:
            #                         if new_pwd==old_pwd:
                                            raise SamePasswordException
#                                             print("New Password cannot be same as the old password")
#                                             continue
                                        else:
                                            
                                            '''Extra Functionality'''
                                            change=set_admin_password(new_pwd)
                                            if change==1:
                                                password_flag=0     #for getting out of the loop for changing password
                                            
                  
                                    except SamePasswordException as e:
                                        print(e)                  
                                                
                            '''Edit Module'''
                            if (command.lower()).find("edit")==0:
                                action=command.lower()
                                
# elif action.lower()[0:4]=="edit":            #EDIT OLD QUESTION
                                if len(action)==9:                        #EDIT WITH QUESTION-ID
                                    question_id=action[5:9]
                                    result=show_question(question_id)
                                    if result==False:
                                        continue
                                    else:
                                        print("Old Question:",result[0])
                                        new_question=input("New Question")
                                        new_question=new_question.title()
                                        print("Old Category:",result[1])
                                        new_category=input("New Category")
                                        new_category=new_category.title()
                                        print("Old Level:",result[2])
                                        new_level=input("New Level")
                                        new_level=new_level.title()
                                        if new_question=="" and new_category=="" and new_level=="":
                                            print("No editing done")
                                        elif result[0]!=new_question and result[1]!=new_category and result[2]!=new_level:
                                            result=edit_question(question_id, new_category, new_question, new_level)
                                            if result==True:
                                                print("Question successfully Edited....")
                                        else:
                                            print("please re-enter the details:")
                                            continue
                                elif len(action)==4:                              #EDIT WITH SELECTION MENU
                                    result=recently_edited_question()
                                    if result!=False:
                                        print("Recently Edited Questions:")
                                        for item in result:
                                            print(item[0],' ',item[1],' ',item[2])
                                    else:
                                        print("No recently edited questions.....")
                                        
                                    print("PyAngMan Edit Question:") 
                                    action2=input("Enter Question Number/Category/ALL/QUIT:")
                                    if action2.isnumeric():
                                        result=show_question(action2)
                                        if result==False:
                                            continue
                                        else:
                                            print("Old Question:",result[0])
                                            new_question=input("New Question")
                                            new_question=new_question.title()
                                            print("Old Category:",result[1])
                                            new_category=input("New Category")
                                            new_category=new_category.title()
                                            print("Old Level:",result[2])
                                            new_level=input("New Level")
                                            new_level=new_level.title()
                                            if new_question=="" and new_category=="" and new_level=="":
                                                print("No editing done")
                                            elif result[0]!=new_question or result[1]!=new_category or result[2]!=new_level:
                                                result=edit_question(action2, new_category, new_question, new_level)
                                                if result==True:
                                                    print("Question successfully Edited....")
                                            else:
                                                print("please re-enter the details:")
                                                continue
                                            
                                    elif action2.lower()!="all" and action2.lower()!="quit":  #EDIT WITH CATEGORY
                                        action1=action2.lower()
                                        question_list=show_by_category(action1)
                                        if question_list==False:
                                            continue
                                        else:
                                            for item in question_list:
                                                print(item[0],' ',item[1],' ',item[2],' ',item[3])
                                            action2=input("Enter Question Number:")
                                            if action2.isnumeric():
                                                result=show_question(action2)
                                                if result==False:
                                                    continue
                                                else:
                                                    print("Old Question:",result[0])
                                                    new_question=input("New Question")
                                                    new_question=new_question.title()
                                                    print("Old Category:",result[1])
                                                    new_category=input("New Category")
                                                    new_category=new_category.title()
                                                    print("Old Level:",result[2])
                                                    new_level=input("New Level")
                                                    new_level=new_level.title()
                                                    if new_question=="" and new_category=="" and new_level=="":
                                                        print("No editing done")
                                                    elif result[0]!=new_question and result[1]!=new_category and result[2]!=new_level:
                                                        result=edit_question(action1, new_category, new_question, new_level)
                                                        if result==True:
                                                            print("Question successfully Edited....")
                                                    else:
                                                        print("please re-enter the details:")
                                                        continue
                                    elif action.lower()[0:4]=="quit":
                                        continue
                                    
                                    elif action2.lower()=="all":                              #EDIT WITH ALL QUESTION
                                        print("all")
                                        question_list=show_all()
                                        for item in question_list:
                                            print(item[0],' ',item[1],' ',item[2],' ',item[3])
                                        action1=input("Enter Question Number:")
                                        if action1.isnumeric():
                                            result=show_question(action1)
                                            if result==False:
                                                continue
                                            else:
                                                print("Old Question:",result[0])
                                                new_question=input("New Question")
                                                new_question=new_question.title()
                                                print("Old Category:",result[1])
                                                new_category=input("New Category")
                                                new_category=new_category.title()
                                                print("Old Level:",result[2])
                                                new_level=input("New Level")
                                                new_level=new_level.title()
                                                if new_question=="" and new_category=="" and new_level=="":
                                                    print("No editing done")
                                                elif result[0]!=new_question and result[1]!=new_category and result[2]!=new_level:
                                                    result=edit_question(action1, new_category, new_question, new_level)
                                                    if result==True:
                                                        print("Question successfully Edited....")
                                                else:
                                                    print("please re-enter the details:")
                                                    continue
                                else:
                                    print("Invalid Input")            
#                                 print("edited")
                            '''Add Module'''
                            if command.lower()[0:3]=="add":
                                result=show_recent_question()
                                if result!=False:
                                    print("Recently Added Questions:")
                                    for item in result:
                                        print(item[0],' ',item[1],' ',item[2])
                                else:
                                    print("No recently added questions.....")
                                while(True):
                                    category=input("Category:")
                                    category=category.title()
                                    name=input("New Question Name:")
                                    name=name.title()
                                    level=input("Level:")
                                    level=level.title()
                                    hint=input("Question Hint:")
                                    hint=hint.title()
                                    result=add_question(category,name,level,hint)
                                    if result==True:
                                        print("Record inserted successfully....")
                                        '''....................................................................'''
                                    des=input("Do you want to add another (y/n)?")
                                    if(des.lower()=="y"):
                                        continue
                                    elif(des.lower()=="n"):
                                        break
                                    else:
                                        print(" Invalid input")
                                        break
                                    
                                    
#                                 print("added")
                            '''Delete Module'''
                            if (command.lower()).find("delete")==0:
                                action=command.lower()
                                if action[0:6].lower()=="delete":    #DELETE WITH SELECTION
                                    if len(action)==11:                  #DELETE WITH QUESTION-ID
                                        question_list=show_question(action[7:11])
                                        if question_list==False:
                                            continue
                                        else:
                                            print("Question:",question_list[0])
                                            print("Category:",question_list[1])
                                            print("Level:",question_list[2])
                                            print("Do you really want to delete:Y-yes/N-No?")
                                            action1=input()
                                            if action1.lower()=='y':
                                                result=delete_question(action[7:11])
                                                if result==False:
                                                    continue
                                                else:
                                                    print("Question deleted....")
                                                    print("Do you want to undo the last deleted:Y-yes/N-No?")
                                                    action1=input()
                                                    if action1.lower()=='y':
                                                        result=undo_deleted_question(result)
                                                        if result==True:
                                                            print("Question added back Successfully")
                                                    else:
                                                        continue                                
                                            else:
                                                print("thank you...")
                                    elif len(action)==6: #DELETE WITH ONE FILTER(NAME/CATEGORY/LEVEL)
                                        question=input("PyAngMan Question:")
                                        category=input("Category:")
                                        level=input("Level:")   
                                        inputlist=[]
                                        inputlist.append(question.upper())
                                        inputlist.append(category.upper())
                                        inputlist.append(level.upper())
                                        result=delete_pattern(inputlist)
                                        if len(result)!=0:
                                            for item in result:
                                                print(item[0],' ',item[1],' ',item[2],' ',item[3])
                                            ids=input("Enter Question-id(s) to delete:")
                                            if len(ids)!=0:
                                                items=ids.split(',')
                                                for item in items:
                                                    question_list=show_question(item)
                                                    if question_list==False:
                                                        continue
                                                    else:
                                                        print("Question:",question_list[0])
                                                        print("Category:",question_list[1])
                                                        print("Level:",question_list[2])
                                                        print("Do you really want to delete:Y-yes/N-No?")
                                                        action1=input()
                                                        if action1.lower()=='y':
                                                            result=delete_question(item)
                                                            if result==False:
                                                                continue
                                                            else:
                                                                print("Question deleted....")
                                                                print("Do you want to undo the last deleted:Y-yes/N-No?")
                                                                action1=input()
                                                                if action1.lower()=='y':
                                                                    result=undo_deleted_question(result)
                                                                    if result==True:
                                                                        print("Question added back Successfully")
                                                                else:
                                                                    continue
                                                        else:
                                                            print("Thank You...")
                                        else:
                                            print("No matching record found...")    
                                    else:
                                        print("Invalid Input")        
#                                 print(("deleted"))
                            '''Logout Module'''
                            if command.lower()=="logout":
                                    flag=0
                                    break
                    except InvalidCommand as e:
                        print(e)  
                    except PasswordChangeLimit as e:
                        print(e)
                    except InvalidPasswordException as e:
                        print(e)   
                if flag==0:
                    break      
        except InvalidPasswordException as e:
            print(e)
    
        except:
            print("Some Error Occured.Try Again Later")
        
#Trainee2
def show_questions_list():
    easy_list=SetLevel.Action_Items_Easy()      
    if easy_list!=0:    #prints header only if questions present
        print("===============================")
        print("Action Items:")
        print("Following questions seems Easy:")
        traverse_list(easy_list)        #printing question id of Questions

    else:
        pass        #if no questions exist,header and sub-header are not printed
    '''Fetching list of Medium questions '''
    medium_list=SetLevel.Action_Items_Medium()      
    if medium_list!=0:      #prints header only if questions present
        print("Following questions seems Medium:")
        traverse_list(medium_list)#printing question id of Questions

    else:
        pass        #if no questions exist,header and sub-header are not printed
    '''Fetching list of hard questions '''
    hard_list=SetLevel.Action_Items_Hard()
    if hard_list!=0:        #prints header only if questions present
        
        print("Following questions seems Hard:")
        traverse_list(hard_list)#printing question id of Questions

    else:
        pass        #if no questions exist,header and sub-header are not printed

#Trainee2
def set_admin_password(new_pwd):
    try:
        valid=Validate.Validate_Admin_Password(new_pwd)  
        '''checks whether new password has maximum character length greater than 8
        and contains at-least one special character and one digit'''     

        
        if valid==True:
            confirm_password=input("Confirm Password: ")     #User's confirm password did not match with the new password
            i=1     #for asking for confirm password only 3 times
            while(confirm_password!=new_pwd and i<3):       #asking for confirm password again and again
                confirm_password=input("Confirm Password: ")
                i+=1
            
            if i==3:
                raise PasswordChangeLimit    
            if confirm_password==new_pwd:
                SetLevel.Change_Password(new_pwd)       #set new password in the database
                print("Password Changed.")
                return 1
                                         
            
    except NumberException as e:
        print(e)
    except LengthException as e:
        print(e)
    except UpperCaseException as e:
        print(e)
    except SpecialCharacterException as e:
        print(e)
    except SpaceException as e:
        print(e)

#Trainee2        
def traverse_list(temp_list):
    for i in range(0,len(temp_list)):
        if i==len(temp_list)-1:
            print(str(temp_list[i][0]))
        else:         
            print(str(temp_list[i][0])+",",end=" ")




        

