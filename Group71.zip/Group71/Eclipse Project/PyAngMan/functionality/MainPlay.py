
from database import PlayQuestions

def play_now(category_play):
    
    return PlayQuestions.fetch_questions(category_play)
    
    
