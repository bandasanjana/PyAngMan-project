
from functionality import LeaderTop,EnteringIntoGame,Play

from database import AddOnDb,CheckNewCateg
from exceptions import CustomExceptions
from validations import Validate

def menu_to_add():
    ''' here the first menu is coded '''
    end=False
    while(end==False):
        #menu with add on feature here point 2 is an add on feature
        print("==========================")
        print("1. Leader Board in general")#leader board project functionality
        print("2. Personalized search")#add on feature
        print("3. Go Back")
        print("==========================")
        
        option=input()
        try:
            Validate.validate1_3(option)
            if(int(option)==1):
                leader_pres()
            elif(int(option)==2):
                Personality=input("Name of the person you want to search")
                person_details(Personality)
            elif(int(option)==3):
                return
        except CustomExceptions.NotRightInputException as e:
            print(e)
        except CustomExceptions.InvalidInputLeaderboard as e:
            print(e)
        except Exception:
            print("database error")



''' method for personal detail fetching'''            
def person_details(Personality):
    rank=0
    occurance=AddOnDb.data_add_on(Personality)
    if(occurance=="no"):
        return#here if there is no person as such then this error will occur
    else:
        print("name ::"+Personality)
        print("city :: "+occurance[0].get_city())
        print("==========================")
        if(len(occurance)==3):# here length 3 means .. country ,, city and rank
            rank=occurance[2]
            print("overall rank ::"+str(rank))
            print(occurance[0].get_category_name()+" :"+str(occurance[0].get_points()))
            print(occurance[1].get_category_name()+" :"+str(occurance[1].get_points()))
            print("Total: "+str(occurance[0].get_points()+occurance[1].get_points()) )
        else:
            rank=occurance[1]
            print("overall rank ::"+str(rank))
            print(occurance[0].get_category_name()+" :"+str(occurance[0].get_points()))
        print("==========================")
        return


def leader_pres():
    #menu_to_add()
    '''checking user credentials'''
    while(True):
        name=input("Enter your name") 
        try:
            Validate.validate_name(name)
            break
        except CustomExceptions.Space_Not_AllowedException as e:
            print(e)
        except CustomExceptions.Only_Num_SpecialException as e:
            print(e)

    while(True):
        city=input("Enter your city:") 
        check=Validate.check_city(name, city)
        # here it is checked whether the user is existing ,new,has entered wrong city 
        if(check=="new" or check=="existing"):
            break
        
        elif(check=="bad_city"):
            while(True):
                #fetches y,n from user and looped
                try:
                    desire=input("enter  N  to go back or enter Y to enter city again")
                    if(desire.lower()=='n'):
                        return
                    elif(desire.lower()=="y"):
                        break
                    else:
                        raise CustomExceptions.InvalidInputLeaderboard
                except CustomExceptions.InvalidInputLeaderboard as e:
                    print(e) 
                
    
    top_players=LeaderTop.top_leader(city)
    count=len(top_players)
    print("PyAngMan Leader Board:")
    if(count==0):
            print("==========================")
            print('No Players Found')
            print("==========================")
    else:
        des=filter_players(top_players,count,name,city,check)
        if(des=="n"):
            return
        
        
def filter_players(top_players,count,name,city,check):
        city1=city.upper()
        print("==========================")
        print("Top "+str(count)+" Players Belong to the city  :"+city1)
        print("==========================")
        for row in range(0,count):
            #print(str(row+1)+"\t"+top_players[row].get_player_name()+"\t\t"+str(top_players[row].get_points()))
            print(' {:<5}{:<30}{:<5}'.format((row+1), top_players[row].get_player_name(),(top_players[row].get_points())))
            #print(' {:<5}{:<20 }{:<5}'.format("sasa", "sasas","sasa"))
            
     
        print("==========================")
        flag=1

        while(flag):
            while(True):
                try:
                    filter_choice=input("Do you wish to apply filter (Y/N )?")
                    valid=Validate.Validate_Y_or_N(filter_choice)
                    if(valid):
                        if(filter_choice.lower()=="y"):
                            break
                        elif(filter_choice.lower()=="n"):
                            return
                    else:
                        raise CustomExceptions.InvalidInputLeaderboard
                except CustomExceptions.InvalidInputLeaderboard as e:
                    print(e)

            
            while(True):
                flag=1
                try:

                    players=(input("No. of Players to be displayed (3-10):") )
                    valid=Validate.validate3_10(players)
                    if(valid ==True and players==""):
                        players=5
                        break
                    if(valid ==True and players!=""):
                        players=int(players)
                        break
                    

                except CustomExceptions.InvalidInputLeaderboard as e:
                    flag=0
                    print(e)

                except Exception:
                    print("some error occurred")
            while(True):
                print("Select category from below")
                print("1. Country")
                print("2. Movies")
                category1=input()
                category2=category1.lower()
                if(category2!="country" and  category2!="movies" and category2!=""):
                    print("** CATEGORY '"+category1+"' NOT FOUND")
                    wish=input("Do you wish to continue (Y/N)? ")
                    if(wish.lower()=="y"):
                        continue
                    elif(wish.lower()=="n"):
                        menu_to_add()
                    else:
                        print("please enter valid input")
                else:
                    break
                
            
            while(True):
                details_show=input("Details: ")
                to_show=[]
                if(details_show==""):
                    to_show.append("Name")
                else:
                    to_show=details_show.split(",")
                
                top_players_category=LeaderTop.top_category_function(category1,players,to_show,city)
                if (top_players_category!=1):
                    break
            count=len(top_players_category)
          
    
        
            if(count==0):
                print('No Players Found')
            else:
                print("==========================")
                print("Top "+str(count)+" Players in Category  "+category1.upper())
                print("==========================")
                for row in range(0,count):
                        print(str(row+1)+"\t"+top_players_category[row].player_details())
         
            print("==========================")
            if(category1!=""):
                while(True):
                    wanna=input("Press 'P' to play in this category:")
                    if(wanna==""):
                        break
                    
                    elif(wanna.lower()=="p"):
                        print("going play")
                       
                        if(check=="new" ):
                            
                            EnteringIntoGame.enter_into_game(name,city,category1)
                        else:
                            CheckNewCateg.category_check(name, city, category1)
                        
                        data="ep"
                        des=Play.start_playing(name,city,category1.title(),data)
                        if(des=="n"):
                            return
                        break
                    else:
                        print("give right input")
    
    

    
