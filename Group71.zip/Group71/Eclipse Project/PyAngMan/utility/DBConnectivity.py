
import cx_Oracle
def create_connection():
    return cx_Oracle.Connection('T751429/T751429@10.123.79.60:1521/georli05')

def create_cursor(con):
    return cx_Oracle.Cursor(con)