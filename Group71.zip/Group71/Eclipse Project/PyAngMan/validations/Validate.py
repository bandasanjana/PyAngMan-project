
from database import CheckingCityName
from exceptions import CustomExceptions
from functionality import SetLevel

def check_city(name,city):
    return CheckingCityName.checkviadb(name, city)

def Validate_Y_or_N(data):
    if data.lower()=='y' or data.lower()=='n':
        return True
    return False

def Validate_E_or_N(data):
    if data.lower()=='e' or data.lower()=='n':
        return True
    return False

def validate3_10(players):
    if((not players.isdigit()) and   players!=""  ):
        raise CustomExceptions.InvalidInputLeaderboard
    elif(players==""):
        return True
    elif(int(players)>=3 and int(players)<=10):
        return True
    else:
        raise CustomExceptions.InvalidInputLeaderboard
    
def validate1_3(option):
    if(option.isdigit() and (int(option)>=1 and int(option)<=4)):
        return True          
    elif(option.isdigit() and not (int(option)>=1 and int(option)<=4)):
        raise CustomExceptions.NotRightInputException
    else:
        raise CustomExceptions.InvalidInputLeaderboard
    
def validate_guess(guess):
        #length=1
        #guess==#,0
        #alphabet
        #alphabet not pressed b4
    if(len(guess)==1):
        if(guess=="#"):
            return "cheat code"
        elif(guess=="0"):
            return "End game"
        elif(guess.isalpha()):
            return True   
        else:
            return False
    else:
        return False
    
def validate_name(name):
    count_spl=0
    count_alp=0
    count_dig=0
    for x in name:
        if (ord(x)>=48 and ord(x)<=57):   #for number
            count_dig+=1
        elif (x.lower()>='a' and x.lower()<='z'):
            count_alp+=1
        elif (ord(x)>=33 and ord(x)<=47) or(ord(x)>=58 and ord(x)<=64) or (ord(x)>=91 and ord(x)<=96) or (ord(x)>=123 and ord(x)<=126):
            count_spl+=1                #for special character
        elif (ord(x)==32):
            raise CustomExceptions.Space_Not_AllowedException   
    if((count_spl>=0 or  count_dig>=0) and count_alp>0 ):# 12@
        return True
    else:
        raise CustomExceptions.Only_Num_SpecialException





#########33
def Validate_Password(pwd):
    old_pwd=SetLevel.Old_Password()
    if pwd==old_pwd:
        return True
    return False

def Validate_Command(command):
    
    command=command.lower()
    list_possible=command.split(" ")
    if (len(list_possible)==1):
        if (command in ["password","add","logout"] or list_possible[0].lower()=="edit"  or list_possible[0].lower()=="delete"):
            return True
    elif(len(list_possible)==2):
        if( (list_possible[0].lower()=="edit"  or list_possible[0].lower()=="delete") and list_possible[1].isdigit()):
            return True
        
    return False
    
def Validate_Admin_Password(pwd):
    num=0
    upp=0
    spl=0
    space=0
    if len(pwd)<8:
        raise CustomExceptions.LengthException
    for char in pwd:
        if (ord(char)>=48 and ord(char)<=57):   #for number
            num=1
            
        elif ord(char)>=65 and ord(char)<=90:     #for uppercase
            upp=1
            
        elif (ord(char)>=33 and ord(char)<=47) or(ord(char)>=58 and ord(char)<=64) or (ord(char)>=91 and ord(char)<=96) or (ord(char)>=123 and ord(char)<=126):
            spl=1                #for special character
        elif (ord(char)==32):
            space=1    
#     if count<3:
#         return False
    if num==0:
        raise CustomExceptions.NumberException
    if upp==0:
        raise CustomExceptions.UpperCaseException
    if spl==0:
        raise CustomExceptions.SpecialCharacterException
    if space==1:
        raise CustomExceptions.SpaceException
        
        
    return True 
# Validate_Admin_Password("helloooooo@A1")    


